package q17_failfastsafe;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create an ArrayList of integers
        List<Integer> arraylist = new ArrayList<>();
        arraylist.add(1);
        arraylist.add(2);
        arraylist.add(3);

        // Fail-fast iterator
        Iterator<Integer> itr = arraylist.iterator();
        while (itr.hasNext()) {
            int num = itr.next();
            System.out.println(num);
            arraylist.remove(1); // Throws ConcurrentModificationException
        }

        // Fail-safe iterator
        Iterator<Integer> itr2 = arraylist.iterator();
        while (itr2.hasNext()) {
            int num = itr2.next();
            System.out.println(num);
            arraylist.remove(1); // Does not throw any exception
        }

	}

}
