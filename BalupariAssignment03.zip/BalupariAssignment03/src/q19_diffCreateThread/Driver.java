package q19_diffCreateThread;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Creating an instance of the thread and starting it
		MyThread myThread1 = new MyThread();
		myThread1.start();
		
		// Creating an instance of the Runnable and passing it to the Thread constructor
		MyRunnable myRunnable = new MyRunnable();
		Thread myThread2 = new Thread(myRunnable);
		myThread2.start();
		
	}

}
