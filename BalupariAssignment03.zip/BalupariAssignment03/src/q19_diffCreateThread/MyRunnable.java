package q19_diffCreateThread;

public class MyRunnable implements Runnable {
    public void run() {
        // Code to be executed in this thread
    }
}
