package q19_diffCreateThread;

public class MyThread extends Thread {
    public void run() {
        // Code to be executed in this thread
    }
}