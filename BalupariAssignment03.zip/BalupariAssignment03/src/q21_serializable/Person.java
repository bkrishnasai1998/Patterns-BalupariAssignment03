package q21_serializable;

import java.io.Serializable;

class Person implements Serializable {
    String pName;
    int pAge;

    public Person(String pName, int pAge) {
        this.pName = pName;
        this.pAge = pAge;
    }
}