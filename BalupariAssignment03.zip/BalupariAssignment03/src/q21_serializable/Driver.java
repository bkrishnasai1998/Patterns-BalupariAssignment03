package q21_serializable;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person person = new Person("Dhoni", 42);

        try {
            // Serialize the object
            FileOutputStream fileOut = new FileOutputStream("person.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(person);
            out.close();
            fileOut.close();
            System.out.println("Object has been serialized");

        } catch (IOException e) {
            e.printStackTrace();
        }

	}

}
