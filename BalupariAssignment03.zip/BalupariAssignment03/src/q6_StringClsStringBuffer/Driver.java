package q6_StringClsStringBuffer;

public class Driver {
	
	public static void main(String[] args) {
        String s = "Northwest";
        StringBuffer stringBuffer = new StringBuffer("Northwest");
        
        // Modify the value of the String and the StringBuffer
        s += " bearcats";
        stringBuffer.append(" bearcats");
        
        System.out.println("String: " + s);
        System.out.println("StringBuffer: " + stringBuffer);
    }

}
