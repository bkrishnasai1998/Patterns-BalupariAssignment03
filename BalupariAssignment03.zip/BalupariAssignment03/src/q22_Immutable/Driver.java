package q22_Immutable;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ImmutableStringClass immutableStr = new ImmutableStringClass(0);
		System.out.println(immutableStr.getValue());
		
		
		String str = "Northwest";
		str = str.concat(" Bearcat"); // creates a new string object
		System.out.println(str);
		
	}

}
