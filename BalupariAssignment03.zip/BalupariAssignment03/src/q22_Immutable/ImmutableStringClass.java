package q22_Immutable;

public class ImmutableStringClass {
	
	private final int value;

    public ImmutableStringClass(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
	
}
