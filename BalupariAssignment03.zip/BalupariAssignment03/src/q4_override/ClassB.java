package q4_override;

public class ClassB extends ClassA {

	// This method is a new method, not an overridden version of myPrivateMethod()
    public void myPrivateMethod() {
        System.out.println("This is a new method in Subclass");
    }
	
}
