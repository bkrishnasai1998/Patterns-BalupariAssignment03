package q4_override;

public class Driver {

	public static void main(String[] args) {
        ClassB classObj = new ClassB();
        classObj.myPrivateMethod(); // Output: This is a new method in Subclass
    }
	
}
