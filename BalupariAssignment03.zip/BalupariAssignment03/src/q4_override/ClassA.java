package q4_override;

public class ClassA {

	private void myPrivateMethod() {
        System.out.println("This is a private method in Superclass");
    }
	
}
