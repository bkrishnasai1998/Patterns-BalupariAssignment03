package q8_trywithoutcatch;

public class TryWithoutCatchExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
            // Code that may throw an exception goes here
            System.out.println("Inside try block");
        } finally {
            // Code that should be executed regardless of whether an exception is thrown or not
            System.out.println("Inside finally block");
        }
	}

}
