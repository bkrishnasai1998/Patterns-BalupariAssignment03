package q13_VectorArrayList;

import java.util.ArrayList;
import java.util.Vector;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer> vectorObj = new Vector<>();
        ArrayList<Integer> arrayListObj = new ArrayList<>();

        // Add elements to Vector and ArrayList
        for (int i = 0; i < 1000000; i++) {
        	vectorObj.add(i);
        	arrayListObj.add(i);
        }

        // Measure the time taken to access elements using a for loop
        long start = System.currentTimeMillis();
        for (int i = 0; i < vectorObj.size(); i++) {
            int element = vectorObj.get(i);
        }
        long end = System.currentTimeMillis();
        System.out.println("Time taken by Vector: " + (end - start) + "ms");

        start = System.currentTimeMillis();
        for (int i = 0; i < arrayListObj.size(); i++) {
            int element = arrayListObj.get(i);
        }
        end = System.currentTimeMillis();
        System.out.println("Time taken by ArrayList: " + (end - start) + "ms");
	}

}
