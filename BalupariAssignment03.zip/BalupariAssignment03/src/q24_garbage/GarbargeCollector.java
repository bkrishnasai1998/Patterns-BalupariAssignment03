package q24_garbage;

public class GarbargeCollector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// create some objects
        Object obj1 = new Object();
        Object obj2 = new Object();

        // call the garbage collector explicitly
        System.gc();

        // wait for a short while to allow the garbage collector to run
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // check if the objects have been garbage collected
        if (obj1 == null) {
            System.out.println("obj1 has been garbage collected");
        } else {
            System.out.println("obj1 has not been garbage collected");
        }

        if (obj2 == null) {
            System.out.println("obj2 has been garbage collected");
        } else {
            System.out.println("obj2 has not been garbage collected");
        }
		
	}

}
