package q1_generics;

public class Generics<T> {
	
	
	    private T items;

	    public void setContents(T items) {
	        this.items = items;
	    }

	    public T getContents() {
	        return items;
	        
	 	}

		public Generics(T items) {
			super();
			this.items = items;
		}

		public static void main(String args[]) {
			Generics<String> genc = new Generics<String>("Balloons");
			System.out.println(genc.getContents());
		}
		
}
