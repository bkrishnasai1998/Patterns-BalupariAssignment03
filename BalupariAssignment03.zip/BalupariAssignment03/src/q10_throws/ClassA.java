package q10_throws;

import java.io.IOException;

public class ClassA {
	
	    void method1() throws IOException {
	        // Some code that may throw an IOException
	    }
	
}
