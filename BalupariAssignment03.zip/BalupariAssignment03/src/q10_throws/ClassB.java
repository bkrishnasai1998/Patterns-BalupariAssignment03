package q10_throws;

import java.io.IOException;

public class ClassB extends ClassA {
	
	// This is a valid override
    //void method1() throws IOException {
        // Same signature as the superclass method, so no new exceptions are thrown
        // Some code that may throw an IOException
    //}
    
 // This is also a valid override
    void method2() {
        // This method doesn't throw any exceptions
    }
    
 // This is a valid override - it throws a subclass of the IOException declared in the superclass method
   // void method1() throws FileNotFoundException {
        // Same signature as the superclass method, but throws a FileNotFoundException (which is a subclass of IOException)
        // Some code that may throw a FileNotFoundException
    //}
    
}
