package q20_threadstate;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread thread = new Thread(new MyRunnable());

        System.out.println("Thread state: " + thread.getState()); // NEW

        thread.start();
        System.out.println("Thread state: " + thread.getState()); // RUNNABLE

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Thread state: " + thread.getState()); // TIMED_WAITING

        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Thread state: " + thread.getState()); // TERMINATED
    }

    static class MyRunnable implements Runnable {
        @Override
        public void run() {
            System.out.println("Thread running...");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread finished.");
        }
		
	}

}
