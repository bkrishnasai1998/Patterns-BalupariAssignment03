package q14_arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list1 = new ArrayList<>();
		List<String> synchronizedList = Collections.synchronizedList(list1);
		
		List<String> list2 = new ArrayList<>();
		synchronized (list2) {
		    // Access or modify the elements of the list
		}



	}

}
