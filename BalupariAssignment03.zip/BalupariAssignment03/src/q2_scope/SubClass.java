package q2_scope;

public class SubClass extends SuperClass {
	// Override the public method and widen the access level to public
    public void publicMethod() {
        System.out.println("This is a public method in the subclass.");
    }
    
    // Override the protected method and widen the access level to public
    public void protectedMethod() {
        System.out.println("This is a public method in the subclass.");
    }
    
    // Override the default method and keep the access level as default
    void defaultMethod() {
        System.out.println("This is a default method in the subclass.");
    }
    
    // You cannot override the private method since it is not visible in the subclass
}
