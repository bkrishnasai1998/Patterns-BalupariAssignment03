package q9_trywithresource;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Driver {

	public static void main(String args[]) throws FileNotFoundException {
		try (PrintWriter writer = new PrintWriter(new File("test.txt"))) {
		    writer.println("Hello World");
		}
	}

}
