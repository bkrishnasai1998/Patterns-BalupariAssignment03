package q12_final;

public class ExpClass {
	
	public static void main(String args[]) {

	final int MAX_VALUE = 100;
	
	try {
	    // some code that may throw an exception
		
	} catch (Exception e) {
	    // exception handling code
	} finally {
	    // code that will always execute
		
	}
	
	}
	
	protected void finalize() {
        // perform cleanup operations here
    }
	
}
