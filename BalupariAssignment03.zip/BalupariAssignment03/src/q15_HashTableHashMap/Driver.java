package q15_HashTableHashMap;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Creating a Hashtable
        Map<String, String> hashtable = new Hashtable<>();
        hashtable.put("key1", "value1");
        hashtable.put("key2", "value2");
        // This will throw a NullPointerException
        // hashtable.put(null, "value3");

        // Creating a HashMap
        Map<String, String> hashmap = new HashMap<>();
        hashmap.put("key1", "value1");
        hashmap.put("key2", "value2");
        hashmap.put(null, "value3");

        // Iterating over the Hashtable
        System.out.println("Hashtable:");
        for (Map.Entry<String, String> entry : hashtable.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Iterating over the HashMap
        System.out.println("HashMap:");
        for (Map.Entry<String, String> entry : hashmap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
		
	}

}
