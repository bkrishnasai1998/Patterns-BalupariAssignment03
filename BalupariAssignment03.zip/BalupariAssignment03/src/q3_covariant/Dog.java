package q3_covariant;

class Dog extends Animal {
    @Override
    public Dog reproduce() {
        return new Dog();
    }
}
