package q3_covariant;

class Animal {
    public Animal reproduce() {
        return new Animal();
    }
}
