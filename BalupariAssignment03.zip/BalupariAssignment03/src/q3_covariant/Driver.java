package q3_covariant;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal1 = new Animal();
	    Animal animal2 = new Dog();
	    Animal animal3 = new Cat();
	    
	    Animal newAnimal1 = animal1.reproduce(); // returns an Animal
	    Dog newDog = (Dog) animal2.reproduce(); // returns a Dog
	    Cat newCat = (Cat) animal3.reproduce(); // returns a Cat

	}

}
