package q3_covariant;

class Cat extends Animal {
    @Override
    public Cat reproduce() {
        return new Cat();
    }
}

