package q5_bufferbuilder;

public class Driver {

	public static void main(String[] args) {
        StringBuffer stringBufferObj = new StringBuffer();
        StringBuilder stringBuilderObj = new StringBuilder();
        
        // Append 100,000 characters to each object
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++) {
        	stringBufferObj.append("a");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuffer: " + (endTime - startTime) + "ms");
        
        startTime = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++) {
        	stringBuilderObj.append("a");
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuilder: " + (endTime - startTime) + "ms");
    }

}
